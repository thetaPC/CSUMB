/*
	Bank.java
	
	Abstract: 
	Holds up to five bank accounts for five people using unique account numbers and social security numbers to create them. Deleting accounts can only be done if the account exists based off the account number given. Existing accounts can also update their address. The program also changes the current balance of an existing account as long as it's not a negative number.
	
	
	Maria Loza
	
	19 September 2016
	20 September 2016
	22 September 2016


*/

import java.util.Scanner;

public class Bank  {

	private Account acct[] = new Account[5];
    private String name;
    private String addr;
	private int accNum;
	private int accType;
	private int ssn;
	private double balance;
	
	boolean response0;
	boolean response1;
	boolean response2;
	boolean response3;
	boolean response4;
	
	private String accountholder;
	
	private int numOfAccts = 0;
	
	private double totalBalance;
	
	Scanner keyboard = new Scanner(System.in);
    
    
    public Bank()
    {
		//creates a default constructor
        name = "Unknown";
    }
	
	public Bank(String name)
    {
		//names the bank using the parameter
        this.name = name;
    }
            
			
	public String getBankName()
    {
		//retrieves and shows the bank's name
        return name;
    }		

    
    public boolean openAccount(String custName, String addr, int ssn, int accNum, int accType, double balance) {
		//opens a new account if the ssn and account number is unique
		
		
		if (acct[4] != null) {
			//if bank is full (5 accounts) then accounts can't be open
			System.out.println("Bank full.");
			response0 =  false;
		} else {
			for (int i = 0; i < 5; i++) {
				if (acct[i] != null && accNum == acct[i].getNum() ) {
					//if the account number exists then the account isn't created
					System.out.println("User already has an existing account.");
					response0 =  false;
					i = 6;
				} else if (acct[i] != null && ssn == acct[i].getAcctHolderSSN() ) {
					//if the ssn is already linked then the account isn't created
					System.out.println("Account already created with ssn.");
					response0 =  false;
					i = 6;
				} else if (acct[i] == null) {
					//creates the account
					Account currAcct =  new Account(custName, accNum, accType, ssn, addr, balance);
					acct[i] = currAcct;
					response0 =  true;
					i = 6;
				}
				
				
			}
		}
		
		return response0;
    }
	
	public boolean closeAccount(int accNum)
    {
		for (int i = 0; i < 5; i++) {
			if (acct[i] != null && accNum == acct[i].getNum() ) {
				//if the account number exists then the account is deleted
				acct[i] = null;
				//System.out.println("Deleted.");
				response1 = true;
				i = 6;
			} else {
				response1 = false;
				i = 6;
			}
				
		}
        return response1;

    }
	
	public void bankInfo() {
		System.out.print("Bank Name: " + getBankName() + "\n");
		numOfAccts = 0;
		
		for (int i = 0; i < 5; i++) {
		//prints out everyone's account info
			if (acct[i] != null){
				numOfAccts++;
				
			}
			
		}
		System.out.print("Number of Accounts: " + numOfAccts + "\n");
		
		for (int i = 0; i < 5; i++) {
			if (acct[i] != null) {
				System.out.print("	" + acct[i].getNum() + ": ");
				System.out.printf("$%2.2f", acct[i].getBal());
				System.out.println(" - " + acct[i].getAcctHolderName() + ": " + acct[i].getAcctHolderSSN() );
			}
			
		}
		
		totalBalance = 0;
		for (int i = 0; i < 5; i++) {
			if (acct[i] != null){
				//prints out total balance of combined accounts
				totalBalance += acct[i].getBal();
			}
			
		}
		
		System.out.printf("Bank Total Balance: $%2.2f\n", totalBalance);
	}
	
	public boolean accountInfo(int accNum) {
		//prints out an individual's info
		for (int i = 0; i < 5; i++) {
			//System.out.println(i);
			
			if ( acct[i] != null )  {
				//System.out.println(accNum + "   " + acct[i].getNum());
				if (accNum == acct[i].getNum())
				{
					System.out.println("Account Info: Account Number: " + acct[i].getNum());
				if (acct[i].getType() == 1) {
					System.out.println("	Checking account");
				} else if (acct[i].getType() == 2) {
					System.out.println("	Savings account");
				}
				System.out.printf("	Balance: $%2.2f \n", acct[i].getBal());
				System.out.println("Customer: " + acct[i].getAcctHolderName() + "\n	" + acct[i].getAccHolderAddr() + "\n	SSN: " + acct[i].getAcctHolderSSN() );
				response2 = true;
				//i = 6;
				}
				
			} else {
				response2 = false;
				//i = 6;
			}
			
		}
		return response2;
	}
	
	public boolean updateBalance(int accNum, double bal) {
		for (int i = 0; i < 5; i++) {
			//System.out.println(i);
			
			if ( acct[i] != null )  {
				//System.out.println(accNum + "   " + acct[i].getNum());
				if (accNum == acct[i].getNum())
				{
					if (bal >= 0) {
						//changes the balance if the number is above a negative number
						acct[i].setBalance(bal);
						response3 = true;
					} else {
						response3 =  false;
					}
					
				}
				
			} else {
				response3 = false;
			}
			
		}
		return response3;
	}
	
	public boolean updateAddress(int accNum, String addr) {
		//changes the address if the account number exists
		for (int i = 0; i < 5; i++) {
			//System.out.println(i);
			
			if ( acct[i] != null )  {
				//System.out.println(accNum + "   " + acct[i].getNum());
				if (accNum == acct[i].getNum())
				{
					acct[i].setAddr(addr);
					response4 = true;
				}
				
			} else {
				response4 = false;
			}
			
		}
		return response4;
	}
}