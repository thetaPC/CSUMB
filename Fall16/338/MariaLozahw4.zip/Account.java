/*
	Account.java
	
	Abstract: 
	Keeps track of an individual account. Checking is 1 and savings is 2. It can retrieve account info and change balance and address. 
	
	Maria Loza
	
	19 September 2016
	20 September 2016
	22 September 2016


*/

public class Account  {
    private String name;
    private int number;
    private int type;
    private double balance;
	private Customer accountholder;
	//private Customer accountholder;
    
    
    public Account(String name, int accNum, int accType, int ssn, String addr, double bal)
    {
		//creates an account using the parameters
		accountholder =  new Customer(name, ssn, addr);
        //this.name = name;
        number = accNum;
        type = accType;
		balance = bal;
    }
	
	public int getNum()
    {
		//retrieves and prints account number
        return number;
    }
	
	public double getBal()
    {
		//retrieves and prints current balance
        return balance;
    }
	
	public int getType()
    {
		//retrieves and prints account type
        return type;
    }
	
	public int getAcctHolderSSN()
    {
		//retrieves and prints out ssn using Customer
        return accountholder.getSSN();
    }
	
	public String getAccHolderAddr()
    {
		//retrieves and prints out address using Customer
        return accountholder.getAddr();
    }
	
	public String getAcctHolderName()
    {
		//retrieves and prints out account holder's name using Customer
        return accountholder.getName();
    }
	
	public void setBalance(double bal) {
		//changes balance
		balance = bal;
	}
	
	public void setAddr(String address) {
		//changes address using Customer
		accountholder.setAddr(address);
	}
	
	
	
	
}