/*
	Custumer.java
	
	Abstract: 
	Stores customers' information. Address can also be changed. 
	
	Maria Loza
	
	19 September 2016
	20 September 2016
	22 September 2016


*/

public class Customer  {
    private String name;
    private int ssn;
    private String addr;
	//private Customer accountholder;
    
    
    public Customer(String name, int ssn, String addr)
    {
		//Customer is created using parameters
        this.name = name;
        this.ssn = ssn;
        this.addr = addr;
    }
            
	public String getName()
    {
		//prints account holder's name
        return name;
    }
	
	public int getSSN()
    {
		//prints ssn
        return ssn;
    }
	
	public String getAddr()
    {
		//prints address
        return addr;
    }
	
	public void setAddr(String address) {
		//changes address
		addr = address;
	}
	
	
}