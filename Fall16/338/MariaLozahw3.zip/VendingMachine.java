/*
	VendingMachine.java
	
	Abstract: 
	The program will run a virtual vending machine. Users can buy and/or return any of the four options. The vending machines can be given names and locations. Admins can also reset items and add items. The program can also print out information about a specific vending machine. Comparing vending machines is also a possibility based off equal names and locations. Users will be told if the quantity they have chosen exceeds the machine's current amount. Paying will also be based off the amount of money the user enters. Not enough money prompts an invalid message. Receipts will be displayed, showing the user's purchase information. The machine status of name, location, sold items, and current amount items can also be displayed.
	
	Maria Loza
	
	15 September 2016
	16 September 2016


*/


import java.util.Scanner;

public class VendingMachine
{
	Scanner keyboard = new Scanner(System.in);
	private int serialNum;
	private String location;
	private int numOfWater;
	private int numOfCoffee;
	private int numOfSunChips;
	private int numOfChocoBar;
	
	private int numWaterSold = 0;
	private int numCoffeeSold = 0;
	private int numSunChipsSold = 0;
	private int numChocoBarSold = 0;
	
	private double waterPrice = 1.50;
	private double coffeePrice = 2.00;
	private double sunChipsPrice = 1.00;
	private double chocoBarPrice = 2.50;
	
	private int water = 1;
	private int coffee = 2;
	private int sunChips = 3;
	private int chocoBar = 4;
	
	private int menuChoice;
	private int menuQuantity;
	
	private double money;
	private double totalDue = 0;
	private double change;
	private double tax;
	
	private double waterCharge;
	private double coffeeCharge;
	private double sunChipsCharge;
	private double chocoBarCharge;
	
	public VendingMachine(int serialNum)
	{
		//initializes a machine based off serial number by giving it default info
		this.serialNum = serialNum;
		location = "UNKNOWN";
		numOfWater = 0;
		numOfCoffee = 0;
		numOfSunChips = 0;
		numOfChocoBar = 0;
	}
	
	public VendingMachine(int serialNum, String location)
	{
		//initializes a machine based off serial number and location by giving it default info
		this.serialNum = serialNum;
		this.location = location;
		numOfWater = 0;
		numOfCoffee = 0;
		numOfSunChips = 0;
		numOfChocoBar = 0;
	}
	
	public VendingMachine()
	{
		//initializes a machine by giving it default info
		this.serialNum = 000;
		location = "UNKNOWN";
		numOfWater = 0;
		numOfCoffee = 0;
		numOfSunChips = 0;
		numOfChocoBar = 0;
	}
	
	public String toString()  {	
		//prints out name, location, and quantity info about the machine
		return ("Serial Number: " + serialNum + "\nLocation: " + location + "\nContents: \n	Water: " + numOfWater + "\n	Coffee: " + numOfCoffee + "\n	Sun Chips: " + numOfSunChips + "\n	Choclate Bar: " + numOfChocoBar);
	}
	
	public boolean equals(VendingMachine otherObj) { 
		//compares two machines based off location and name
		return((serialNum == otherObj.serialNum) && (location.equals(otherObj.location) ) ) ;
	}
	
	public void setLocation(String location)
	{
		//assigns or changes the machine's location
		this.location = location;
	}
	
	public void setName(int serialNum) 
	{
		//assigns or changes the machine's name
		this.serialNum = serialNum;
	}
	
	public void addItems(int water, int coffee, int sunChips, int chocoBar) 
	{
		//add items to the current amount
		numOfWater += water;
		numOfCoffee += coffee;
		numOfSunChips += sunChips;
		numOfChocoBar += chocoBar;
	}
	
	public void reset(int water, int coffee, int sunChips, int chocoBar) 
	{
		//resets the machine's quantity to the given quantity
		numOfWater = water;
		numOfCoffee = coffee;
		numOfSunChips = sunChips;
		numOfChocoBar = chocoBar;
	}
	
	public void displayMenu()
	{
		//displays the contents and amount
		System.out.println("==== Vending Machine Menu ====");
		System.out.println("	1. Water............$1.50");
		System.out.println("	2. Regular Coffee...$2.00");
		System.out.println("	3. Sun Chips........$1.00");
		System.out.println("	4. Choclate Bar.....$2.50");
		
	}
	
	public boolean buyItem() 
	{
		//buys an item using user's input
		//failure message will be prompt if the machine doesn't have enough quantity
		//starts keeping track of sold items and items remaining
		System.out.print("Select an item number: ");
		menuChoice = keyboard.nextInt();
		System.out.print("\n");
		System.out.print("How many do you want to buy? ");
		menuQuantity = keyboard.nextInt();
		System.out.print("\n");
		if (menuChoice == 1) {
			System.out.println("You selected Water. Quantity: " + menuQuantity);
			if (numOfWater < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Water.");
				return false;
			} else {
				numOfWater -= menuQuantity;
				numWaterSold += menuQuantity;
				totalDue = totalDue +  waterPrice * menuQuantity;
				return true;
			}
			
			
		} else if (menuChoice == 2) {
			System.out.println("You selected Regular Coffee. Quantity: " + menuQuantity);
			if (numOfCoffee < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Coffee.");
				return false;
			} else {
				numOfCoffee -= menuQuantity;
				numCoffeeSold += menuQuantity;
				totalDue = totalDue + coffeePrice * menuQuantity;
				return true;
			}
			
		} else if (menuChoice == 3) {
			System.out.println("You selected Sun Chips. Quantity: " + menuQuantity);
			if (numOfSunChips < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Sun Chips.");
				return false;
			} else {
				numOfSunChips -= menuQuantity;
				numSunChipsSold += menuQuantity;
				totalDue = totalDue + sunChipsPrice * menuQuantity;
				return true;
			}
			
		} else if (menuChoice == 4) {
			System.out.println("You selected Chocolate Bar. Quantity: " + menuQuantity);
			if (numOfChocoBar < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Chocolate Bar.");
				return false;
			} else {
				numOfChocoBar -= menuQuantity;
				numChocoBarSold += menuQuantity;
				totalDue = totalDue + chocoBarPrice * menuQuantity;
				return true;
			}
			
		} else {
			return false;
		}
		
		
		
	}
	
	public boolean buyItem(int menuChoice, int menuQuantity) 
	{
		//buys an item using given info
		//failure message will be prompt if the machine doesn't have enough quantity
		//starts keeping track of sold items and items remaining
		System.out.print("Select an item number: " +  menuChoice);
		this.menuChoice = menuChoice;
		System.out.print("\n");
		System.out.print("How many do you want to buy? " + menuQuantity);
		this.menuQuantity = menuQuantity;
		System.out.print("\n");
		if (this.menuChoice == 1) {
			System.out.println("You selected Water. Quantity: " + this.menuQuantity);
			if (numOfWater < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Water.");
				return false;
			} else {
				numOfWater -= menuQuantity;
				numWaterSold += menuQuantity;
				totalDue = totalDue + waterPrice * menuQuantity;
				return true;
			}
			
		} else if (this.menuChoice == 2) {
			System.out.println("You selected Regular Coffee. Quantity: " + this.menuQuantity);
			if (numOfCoffee < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Coffee.");
				return false;
			} else {
				numOfCoffee -= menuQuantity;
				numCoffeeSold += menuQuantity;
				totalDue = totalDue + coffeePrice * menuQuantity;
				return true;
			}
			
		} else if (this.menuChoice == 3) {
			System.out.println("You selected Sun Chips. Quantity: " + this.menuQuantity);
			if (numOfSunChips < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Sun Chips.");
				return false;
			} else {
				numOfSunChips -= menuQuantity;
				numSunChipsSold += menuQuantity;
				totalDue = totalDue + sunChipsPrice * menuQuantity;
				return true;
			}
			
		} else if (this.menuChoice == 4) {
			System.out.println("You selected Chocolate Bar. Quantity: " + this.menuQuantity);
			if (numOfChocoBar < menuQuantity){
				System.out.println("Selection Failed. We don't have enough Chocolate Bar.");
				return false;
			} else {
				numOfChocoBar -= menuQuantity;
				numChocoBarSold += menuQuantity;
				totalDue = totalDue + chocoBarPrice * menuQuantity;
				return true;
			}
			
		} else {
			return false;
		}
	}
	
	public boolean returned(int menuChoice, int menuQuantity) 
	{
		//returns an item
		//tracks the amount of items returned by adding it back to the item's quantity 
		//and item's sold
		this.menuChoice = menuChoice;
		this.menuQuantity = menuQuantity;
		
		if (this.menuChoice == 1) {
			System.out.println("You selected Water. Quantity: " + this.menuQuantity);
			numOfWater += menuQuantity;
			numWaterSold -= menuQuantity;
			totalDue = totalDue - waterPrice * menuQuantity;
			return true;
		} else if (this.menuChoice == 2) {
			System.out.println("You selected Regular Coffee. Quantity: " + this.menuQuantity);
			numOfCoffee += menuQuantity;
			numCoffeeSold -= menuQuantity;
			totalDue = totalDue - coffeePrice * menuQuantity;
			return true;
		} else if (this.menuChoice == 3) {
			System.out.println("You selected Sun Chips. Quantity: " + this.menuQuantity);
			numOfSunChips += menuQuantity;
			numSunChipsSold -= menuQuantity;
			totalDue = totalDue - sunChipsPrice * menuQuantity;
			return true;
		} else if (this.menuChoice == 4) {
			System.out.println("You selected Chocolate Bar. Quantity: " + this.menuQuantity);
			numOfChocoBar += menuQuantity;
			numChocoBarSold -= menuQuantity;
			totalDue = totalDue - chocoBarPrice * menuQuantity;
			return true;
		} else {
			return false;
		}
	}
	
	public boolean payment()
	{
		//user pays for the purchased items
		//failure message is prompt if the user does not have enough to pay
		//money is also returned
		//if accepted, then message will be a success
		//change will be given back
		System.out.print("Enter money amount: $");
		money = keyboard.nextDouble();
		tax = totalDue * 0.10;
		tax = Math.round(tax * 100);
		tax = tax / 100;
		totalDue += tax;
		if (money >= totalDue) {
			System.out.print("Sufficient money.");
			if (money > totalDue) {
				change = money - totalDue;
				System.out.printf(" $%2.2f returned", change);
			}
			return true;
		} else if (money < totalDue) {
			System.out.printf("Insufficient money. $%2.2f returned", money);
			totalDue -= tax;
			return false;
		} else {
			return false;
		}
		
	}
	
	public void displayReceipt()
	{
		//displays a receipt based off the user's purchased items
		if (numWaterSold > 0) {
			waterCharge = numWaterSold * waterPrice;
			System.out.printf("	Water: $1.50 X %s = $%2.2f%n", numWaterSold, waterCharge);
		}
		if (numCoffeeSold > 0) {
			coffeeCharge = numCoffeeSold * coffeePrice;
			System.out.printf("	Regular Coffee: $2.00 X %s = $%2.2f%n", numCoffeeSold, coffeeCharge);
		}
		if (numSunChipsSold > 0) {
			sunChipsCharge = numSunChipsSold * sunChipsPrice;
			System.out.printf("	Sun Chips: $1.00 X %s = $%2.2f%n", numSunChipsSold, sunChipsCharge);
		}
		if (numChocoBarSold > 0) {
			chocoBarCharge = numChocoBarSold * chocoBarPrice;
			System.out.printf("	Sun Chips: $1.00 X %s = $%2.2f%n", numChocoBarSold, chocoBarCharge);
		}
		//tax = totalDue * 0.10;
		System.out.printf("	Tax (10.0%%): $%2.2f%n", tax);
		//totalDue += tax;
		System.out.printf("	Total: $%2.2f%n", totalDue);
		
	}
	
	public void status()
	{
		System.out.println("Serial Number: " + serialNum);
		System.out.println("Location: " + location);
		System.out.println("Sold Items: ");
		System.out.println("	Water: " + numWaterSold);
		System.out.println("	Coffee: " + numCoffeeSold);
		System.out.println("	Sun Chips: " + numSunChipsSold);
		System.out.println("	Chocolate Bar: " + numChocoBarSold);
		System.out.println("Current Contents: ");
		System.out.println("	Water: " + numOfWater);
		System.out.println("	Coffee: " + numOfCoffee);
		System.out.println("	Sun Chips: " + numOfSunChips);
		System.out.println("	Chocolate Bar: " + numOfChocoBar);
		System.out.printf("Total Earning: $%2.2f%n", totalDue);
		
	}

}