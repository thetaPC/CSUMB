package io.github.thetapc.otterlibrarysystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.View.OnClickListener;

import java.util.ArrayList;

public class ManageSystem extends AppCompatActivity implements OnClickListener {

    private ArrayList<Logs> allLogs = new ArrayList<Logs>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_system);

        LinearLayout ll = (LinearLayout) findViewById(R.id.activity_manage_system);

        LibraryLogDB db = new LibraryLogDB(this);
        allLogs = db.getAllLogs();

        for (Logs log: allLogs) {
            TextView tv = new TextView(this);
            if (log.getType().equals("New account")) {
                tv.setText("Transaction type: " + log.getType() + " \nCustomer's username: " + log.getUsername() + " \nTransaction date: " + log.getCDate() + " \nTransaction time: " + log.getCTime() + "\n\n");
            } else if (log.getType().equals("Place Hold") || log.getType().equals("Cancel hols")) {
                tv.setText("Transaction type: " + log.getType() + " \nCustomer's username: " + log.getUsername() + " \nBook title: " + log.getTitle()
                        + " \nPick up date/time: " + log.getSDate() + " " + log.getSTime() + " \nReturn date/time: " + log.getEDate()
                        + " " + log.getETime() + " \nReservation number: " + log.getRNum() + " \nTransaction date: "
                        + log.getCDate() + " \nTransaction time: " + log.getCTime() + "\n\n");
            }

            tv.setId(log.getId());
            ll.addView(tv);
        }

        View okBtn = findViewById(R.id.btnOk);
        okBtn.setOnClickListener(this);


    }

    public void onClick(View view) {
        if (view.getId() == R.id.btnOk) {
            Intent nextMng = new Intent(ManageSystem.this, AddBook.class);
            startActivity(nextMng);
        }
    }
}
