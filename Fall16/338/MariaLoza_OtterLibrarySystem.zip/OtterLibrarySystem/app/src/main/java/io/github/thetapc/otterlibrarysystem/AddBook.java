package io.github.thetapc.otterlibrarysystem;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class AddBook extends AppCompatActivity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        View yesBtn = findViewById(R.id.yesBtn);
        yesBtn.setOnClickListener(this);

        View noBtn = findViewById(R.id.noBtn);
        noBtn.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.yesBtn) {
            Intent nextMng = new Intent(AddBook.this, AddNewBook.class);
            startActivity(nextMng);
        }
        if (view.getId() == R.id.noBtn) {
            Intent main = new Intent(AddBook.this, MainActivity.class);
            startActivity(main);
        }
    }
}
