package io.github.thetapc.otterlibrarysystem;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.view.View.OnClickListener;
import android.content.Intent;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements OnClickListener {

    private LibraryAccountDB db;
    private LibraryLogDB logs;

    ArrayList<Acct> allAccts = new ArrayList<Acct>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new LibraryAccountDB(this);
        logs = new LibraryLogDB(this);




  //    logs.deleteTable();

   //  db.deleteTable();

    //  db.addAcct(new Acct("a@lice5", "@csit100"));
   // db.addAcct(new Acct("$brian7", "123abc##"));
   // db.addAcct(new Acct("!chris12!", "CHRIS12!!"));
       allAccts = db.getAllAccts();


        //button selections
        View createAcct = findViewById(R.id.createAcct);
        createAcct.setOnClickListener(this);

        View placeHold = findViewById(R.id.plcHold);
        placeHold.setOnClickListener(this);

        View cancelHold = findViewById(R.id.cnlHold);
        cancelHold.setOnClickListener(this);

        View manageAcct = findViewById(R.id.mgSyst);
        manageAcct.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.createAcct) {
            Intent myIntent = new Intent(MainActivity.this, NewAcct.class);
            Bundle accts = new Bundle();
            myIntent.putExtras(accts);
            startActivity(myIntent);
        }
        if (view.getId() == R.id.plcHold) {
            Intent holdIntent = new Intent(MainActivity.this, PlaceHold.class);
            startActivity(holdIntent);
        }
        if (view.getId() == R.id.cnlHold) {
            Intent cancelIntent = new Intent(MainActivity.this, Login.class);
            startActivity(cancelIntent);
        }
        if (view.getId() == R.id.mgSyst) {
            Intent lib = new Intent(MainActivity.this, Login.class);
            startActivity(lib);
        }
    }
}
