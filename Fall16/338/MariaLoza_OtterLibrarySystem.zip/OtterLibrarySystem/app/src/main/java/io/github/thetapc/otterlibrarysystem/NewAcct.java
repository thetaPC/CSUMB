package io.github.thetapc.otterlibrarysystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.EditText;
import android.view.View.OnClickListener;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class NewAcct extends AppCompatActivity implements OnClickListener {

    private String reserved = "!admin2";
    private static int strikes = 0;
    private ArrayList<Acct> allAccts = new ArrayList<Acct>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_acct);

        Bundle bundle = this.getIntent().getExtras();

       // LibraryAccountDB db = bundle.getAcctArrayList();

        LibraryAccountDB db = new LibraryAccountDB(this);
       // db.addAcct(new Acct("a@lice5", "@csit100"));
       // db.addAcct(new Acct("$brian7", "123abc##"));
       // db.addAcct(new Acct("!chris12!", "CHRIS12!!"));
        allAccts = db.getAllAccts();

        View createNwAcct = findViewById(R.id.doneNewAcct);
        createNwAcct.setOnClickListener(this);
    }

    public void onClick(View view) {


        if (view.getId() == R.id.doneNewAcct) {
            EditText user;
            String userName;
            EditText pass;
            TextView name = (TextView)findViewById(R.id.newAcctName);
            char[] alphabet = {'!', '@', '#', '$'};
            String passWord;
            int symCounter = 0;
            int numCounter = 0;
            int letCounter = 0;
            boolean validUser = false;
            boolean validPass = false;
            boolean sameUser = false;

            Button createAcctBtn = (Button)findViewById(R.id.doneNewAcct);
            user = (EditText)findViewById(R.id.newUser);
            pass = (EditText)findViewById(R.id.newPass);

            user.requestFocus();

            userName = user.getText().toString();
            passWord = pass.getText().toString();

            if (userName.equals(reserved)) {
                showUnavailability(user, "username");
                strikes++;
                user.requestFocus();
            } else if (passWord.equals(reserved)) {
                showUnavailability(pass, "password");
                strikes++;
                pass.requestFocus();
            } else if (userName.equals("")) {
                invalid(user);
            } else if (passWord.equals("")) {
                invalid(pass);
            } else {

                for (Acct acct: allAccts) {
                    String log = " checking db username: " + userName + " " + acct.getUsername();

                    if (userName.equals(acct.getUsername())) {
                        sameUser = true;
                        Log.d("strkes before", Integer.toString(strikes));
                        strikes++;
                        Log.d("strkes after", Integer.toString(strikes));
                        showUnavailabilityUser(user);
                        break;
                    } else {
                        sameUser = false;
                    }
                    Log.d("Acct: ", log);
                }

                if (strikes >= 2) {
                    showUnsuccessful(name);
                    wrong();
                }

                /*
                for (int j = 0; j < allAccts.size(); j++) {
                    if (userName == allAccts.get(j).getUsername()) {
                        sameUser = true;
                        showUnavailability(user, "username");
                        break;
                    } else {
                        sameUser = false;
                    }
                }
                 */

                if (!sameUser) {
                    for (int i = 0; i < userName.length(); i++) {
                        char currCharUser = userName.charAt(i);
                        if (Character.isDigit(currCharUser)) {
                            numCounter++;
                        } else if (Character.isLetter(currCharUser)) {
                            letCounter++;
                        }
                        for (char c: alphabet) {
                            if (c == currCharUser) {
                                symCounter++;
                            }
                        }
                    }

                    if ((letCounter >= 3) && (symCounter >= 1) && (numCounter >= 1)) {
                        validUser = true;

                        symCounter = 0;
                        numCounter = 0;
                        letCounter = 0;

                        for (int i = 0; i < passWord.length(); i++) {
                            char currCharUser = passWord.charAt(i);
                            if (Character.isDigit(currCharUser)) {
                                numCounter++;
                            } else if (Character.isLetter(currCharUser)) {
                                letCounter++;
                            }
                            for (char c: alphabet) {
                                if (c == currCharUser) {
                                    symCounter++;
                                }
                            }
                        }

                        if ((letCounter >= 3) && (symCounter >= 1) && (numCounter >= 1)) {
                            validPass = true;
                        } else {
                            showError(pass);
                            pass.requestFocus();
                            strikes++;
                        }

                    } else {
                        showError(user);
                        user.requestFocus();
                        strikes++;
                    }

                    if (strikes >= 2) {
                        showUnsuccessful(name);
                        wrong();
                    }

                    if (validPass && validUser) {
                        createAcctBtn.setEnabled(false);
                        showSuccess(createAcctBtn);
                        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                        Date currDate;
                        currDate = new Date();
                        String cDate = dateFormat.format(currDate); //11/16/2016
                        DateFormat dateFormat2 = new SimpleDateFormat("hh:mm a");
                        Date currTime;
                        currTime = new Date();
                        String cTime = dateFormat2.format(currTime); // 12:08

                        LibraryAccountDB db = new LibraryAccountDB(this);
                        db.addAcct(new Acct(userName, passWord));

                        LibraryLogDB lLog = new LibraryLogDB(this);
                        lLog.addLog(new Logs("New account", userName, cDate, cTime));

                        confirmDialog();




                    }
                }




            }





        }


    }

    private void confirmDialog() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(NewAcct.this).create();
        alertDialog.setTitle("Success!");
        alertDialog.setMessage("Your account has been created.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Intent myIntent = new Intent(NewAcct.this, MainActivity.class);
                        startActivity(myIntent);

                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void wrong() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(NewAcct.this).create();
        alertDialog.setTitle("Account creation failed.");
        alertDialog.setMessage("2nd Wrong format");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        Intent myIntent = new Intent(NewAcct.this, MainActivity.class);
                        startActivity(myIntent);

                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void showError(EditText format) {
        format.setError("Must have at least one symbol, one number, and 3 letters");
    }

    private void showUnavailabilityUser(EditText format) {
        format.setError("Username already exists.");
    }

    private void showUnavailability(EditText format, String name) {
        format.setError("Choose a different " + name);
    }

    private void showUnsuccessful(TextView format) {
        format.setError("Account creation failed");
    }

    private void test(EditText format) {
        format.setError(" testing ");
    }

    private void showSuccess(Button format) {
        format.setError("Account successful");
    }

    private void invalid(EditText format) {
        format.setError("Invalid");
    }
}
