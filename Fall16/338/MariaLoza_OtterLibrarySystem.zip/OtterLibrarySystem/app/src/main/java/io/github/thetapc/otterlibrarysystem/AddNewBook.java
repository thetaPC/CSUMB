package io.github.thetapc.otterlibrarysystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class AddNewBook extends AppCompatActivity implements OnClickListener {

    private LibraryBookDB db;
    private ArrayList<Book> allBooks = new ArrayList<Book>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_book);

        db = new LibraryBookDB(this);
        allBooks = db.getAllBooks();

        View btnAdd = findViewById(R.id.addBtn);
        btnAdd.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.addBtn) {
            double feePerHr = 0;
            boolean correct = true;
            EditText bkTitle = (EditText)findViewById(R.id.title);
            String title = bkTitle.getText().toString();
            if (title.equals("")) {
                correct = false;
                showError(bkTitle);
            }
            EditText auth = (EditText)findViewById(R.id.auth);
            String author = auth.getText().toString();
            if (author.equals("")) {
                correct = false;
                showError(auth);
            }
            EditText isbnN = (EditText)findViewById(R.id.isbnNum);
            String isbn = isbnN.getText().toString();
            if (isbn.equals("")) {
                correct = false;
                showError(isbnN);
            }
            EditText feeN = (EditText)findViewById(R.id.feeNum);
            String fee = feeN.getText().toString();
            if (fee.equals("")) {
                correct = false;
                showError(feeN);
            } else {
                feePerHr = Double.parseDouble(fee);
            }

            for (Book book: allBooks) {
                if (book.getTitle().equals(title) && book.getAuthor().equals(author) && book.getISBN().equals(isbn) && book.getFee() == feePerHr) {
                    invalidEntry();
                    correct = false;
                }
            }

            if (correct) {

                db = new LibraryBookDB(this);
                db.addBook(new Book(title, author, isbn, feePerHr, "yes"));
                Intent main = new Intent(AddNewBook.this, MainActivity.class);
                startActivity(main);
            }





        }
    }

    private void invalidEntry() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(AddNewBook.this).create();
        alertDialog.setTitle("Invalid");
        NumberFormat format = NumberFormat.getCurrencyInstance();
        alertDialog.setMessage("Book is already in the system");
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code

                        Intent main = new Intent(AddNewBook.this, MainActivity.class);
                        startActivity(main);
                        dialog.dismiss();
                    }
                });

        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void showError(EditText format) {
        format.setError(" Invalid ");
    }
}
