package io.github.thetapc.otterlibrarysystem;

/**
 * Created by Maria on 12/8/2016.
 */

public class Hold {

    private int mID;
    private String mUsername;
    private String mTitle;
    private String mAuthor;
    private String mISBN;
    private double mFee;
    private int mReserveNum;
    private String mPDate;
    private String mPTime;
    private String mRDate;
    private String mRTime;
    private String mTDate;
    private String mTTime;


    public Hold() {
        mUsername = "";
        mTitle = "";
        mAuthor = "";
        mISBN = "";
        mFee = 0;
        mReserveNum = 0;
        mPDate = "";
        mPTime = "";
        mRDate = "";
        mRTime = "";
        mTDate = "";
        mTTime = "";
    }

    public Hold(String user, String title, String author, String isbn, double fee,
                int num, String pDate, String pTime, String rDate, String rTime, String tDate, String tTime) {
        mTitle = title;
        mAuthor = author;
        mISBN = isbn;
        mFee = fee;
        mUsername = user;
        mReserveNum = num;
        mPDate = pDate;
        mPTime = pTime;
        mRDate = rDate;
        mRTime = rTime;
        mTDate = tDate;
        mTTime = tTime;
    }

    public String toString() {
        return "Hold [id=" + mID + ", username=" + mUsername + ", title=" + mTitle + ", author="
                + mAuthor + ", isbn=" + mISBN + ", fee=" + mFee + ", reservation number="
                + mReserveNum + ", pickup date=" + mPDate + ", pickup time=" + mRTime + ", return date="
                + mRDate + ", return time=" + mRTime + ", transaction date=" + mTDate + ", transaction time" +
                mTTime + "]";
    }

    public  String getUsername() { return  mUsername; }

    public String getTitle() {
        return mTitle;
    }

    public String getAuthor() {
        return mAuthor;
    }

    public String getISBN() {
        return mISBN;
    }

    public double getFee() {
        return mFee;
    }

    public String getPDate() { return mPDate; }

    public String getPTime() { return mPTime; }

    public String getRDate() { return mRDate; }

    public String getRTime() { return mRTime; }

    public String getTDate() { return mTDate; }

    public String getTTime() { return mTTime; }

    public int getId() { return mID; }

    public int getReserveNum() { return mReserveNum; }

    public void setId(int ID) {
        mID = ID;
    }

    public void setUsername(String user) {mUsername = user; }

    public void setTitle(String title) {
        mTitle = title;
    }

    public void setAuthor(String author) {
        mAuthor = author;
    }

    public void setISBN(String isbn) {
        mISBN = isbn;
    }

    public void setFee(double fee) {
        mFee = fee;
    }

    public void setReserveNum(int num) { mReserveNum = num; }

    public void setPDate(String date) { mPDate = date; }

    public void setPTime(String time) { mPTime = time; }

    public void setRDate(String date) { mRDate = date; }

    public void setRTime(String time) { mRTime = time; }

    public void setTDate(String date) { mTDate = date; }

    public void setTTime(String time) { mTTime = time; }


}
