package io.github.thetapc.otterlibrarysystem;

import java.util.ArrayList;

/**
 * Created by Maria on 12/1/2016.
 */

public class Acct {
    private int mID;
    private String mUsername;
    private String mPassword;

    public Acct() {
        mUsername = "";
        mPassword = "";
    }

    public Acct(String user, String pass) {
        mUsername = user;
        mPassword = pass;
    }

    public String toString() {
        return "Account [id=" + mID + ", username=" + mUsername + ", password=" + mPassword + "]";
    }

    public String getUsername() {
        return mUsername;
    }

    public String getPassword() {
        return mPassword;
    }

    public int getId() { return mID; }

    public void setId(int ID) {
        mID = ID;
    }

    public void setUser(String user) {
        mUsername = user;
    }

    public void setPass(String pass) {
        mPassword = pass;
    }



}
