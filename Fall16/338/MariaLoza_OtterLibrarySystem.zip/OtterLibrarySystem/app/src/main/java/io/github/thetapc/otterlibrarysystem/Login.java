package io.github.thetapc.otterlibrarysystem;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

import java.util.ArrayList;

public class Login extends AppCompatActivity implements OnClickListener {

    private LibraryAccountDB db;
    ArrayList<Acct> allAccts = new ArrayList<Acct>();
    private String reserved = "!admin2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new LibraryAccountDB(this);
        allAccts = db.getAllAccts();

        View login = findViewById(R.id.loginBtn);
        login.setOnClickListener(this);
    }

    public void onClick(View view) {
        if (view.getId() == R.id.loginBtn) {
            EditText user = (EditText)findViewById(R.id.lUserName);
            String userName = user.getText().toString();
            EditText pass = (EditText)findViewById(R.id.lPassWord);
            String passWord = pass.getText().toString();
            boolean correct = false;
            if (userName.equals(reserved) && passWord.equals(reserved)) {
                Intent librarian = new Intent(Login.this, ManageSystem.class);
                startActivity(librarian);
            } else {
                for (Acct ac: allAccts) {
                    if (userName.equals(ac.getUsername()) && passWord.equals(ac.getPassword())) {
                        correct = true;
                        Log.d("correct 1: ", String.valueOf(correct));
                        Intent myIntent = new Intent(Login.this, CancelHold.class);
                        myIntent.putExtra("username", ac.getUsername());
                        startActivity(myIntent);

                        break;
                    } else {
                        correct = false;
                    }
                }
            }

        }
    }
}
