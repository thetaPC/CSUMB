package io.github.thetapc.otterlibrarysystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.view.View.OnClickListener;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class PlaceHold2 extends AppCompatActivity implements OnClickListener {

    private LibraryBookDB db;
    private LibraryAccountDB acct;
    private ArrayList<Book> allBooks = new ArrayList<Book>();
    private ArrayList<Acct> allAccts = new ArrayList<Acct>();
    private LibraryHoldDB holdBook;
    private LibraryLogDB log = new LibraryLogDB(this);
    private long totalHours;
    private String dateStart;
    private String timeStart;
    private String dateEnd;
    private String timeEnd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_hold2);

        Intent intent = getIntent();
        totalHours = intent.getLongExtra("totalHours", 0) ;
        dateStart = intent.getStringExtra("dateStart");
        dateEnd = intent.getStringExtra("dateEnd");
        timeStart = intent.getStringExtra("timeStart");
        timeEnd = intent.getStringExtra("timeEnd");


        db = new LibraryBookDB(this);
        acct = new LibraryAccountDB(this);
        allAccts = acct.getAllAccts();
        allBooks = db.getAvailBooks();
        holdBook = new LibraryHoldDB(this);

        Spinner book = (Spinner)findViewById(R.id.spinnerBk);
        List<String> list = new ArrayList<String>();
        for (Book bk: allBooks) {
            list.add(bk.getTitle());
        }
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        book.setAdapter(dataAdapter);

        View newHold = findViewById(R.id.plcHold);
        newHold.setOnClickListener(this);
    }

    public void onClick(View view) {


            boolean correct = true;

            Button hold = (Button)findViewById(R.id.plcHold);


            Spinner spinnerBk = (Spinner)findViewById(R.id.spinnerBk);
            String bookTitle = spinnerBk.getSelectedItem().toString();

            EditText user = (EditText)findViewById(R.id.user);
            String userName = user.getText().toString();
            EditText pass = (EditText)findViewById(R.id.pass);
            String passWord = pass.getText().toString();

            double fee = 0;
            double totalFee = 0;
            int confirmNum;

            String author = "";
            String isbn = "";

            if (view.getId() == R.id.plcHold) {


                Log.d("correct 0: ", String.valueOf(correct));

                if (user.getText().toString().equals("")) {
                    invalid(user);
                }
                if(pass.getText().toString().equals("")) {
                    invalid(pass);
                }

                Log.d("user ", userName);
                Log.d("pass ", passWord);
                for (Acct ac: allAccts) {
                    if (userName.equals(ac.getUsername()) && passWord.equals(ac.getPassword())) {
                        correct = true;
                        Log.d("correct 1: ", String.valueOf(correct));
                        break;
                    } else {
                        correct = false;
                    }
                }

                for (Book bk: allBooks) {
                    if (bookTitle.equals(bk.getTitle())) {
                        author = bk.getAuthor();
                        isbn = bk.getISBN();
                        fee = bk.getFee();
                        break;
                    }
                }

                // show(rDay, String.valueOf(correct));
                Log.d("correct: ", String.valueOf(correct));

                if (correct) {

                        confirmNum = ThreadLocalRandom.current().nextInt(123456789, 987654321 + 1);
                        totalFee = fee * totalHours;
                        //show(month, Integer.toString(confirmNum));
                        confirmDialog(userName, dateStart, dateEnd, bookTitle, confirmNum, totalFee, db, holdBook,
                                log, author, isbn, timeStart, timeEnd);


                }
            }



    }

    private void confirmDialog(final String user, final String dateStart, final String dateEnd, final String title,
                               final int confirmNum, final double fee, final LibraryBookDB db,
                               final LibraryHoldDB hold, final LibraryLogDB log, final String author, final String isbn,
                               final String timeStart, final String timeEnd) {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(PlaceHold2.this).create();
        alertDialog.setTitle("Place Hold");
        NumberFormat format = NumberFormat.getCurrencyInstance();
        alertDialog.setMessage("Customer username: " + user + "\nPickup: " + dateStart + " " + timeStart + "\nReturn: " + dateEnd + " " + timeEnd + "\nBook to hold: "
                + title + "\nReservation number: " + confirmNum + "\nTotal amount: " + format.format(fee));
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code
                        for (Book book: allBooks) {
                            if (title.equals(book.getTitle())) {
                                book.setAvailablility("no");
                                db.updateBook(book);
                                DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                                Date currDate;
                                currDate = new Date();
                                String tDate = dateFormat.format(currDate); //11/16/2016
                                DateFormat dateFormat2 = new SimpleDateFormat("HH:mm:ss");
                                Date currTime;
                                currTime = new Date();
                                String tTime = dateFormat2.format(currTime); // 12:08:43
                                hold.addBookToAcct(new Hold(user, title, author, isbn, fee, confirmNum, dateStart, timeStart,
                                        dateEnd, timeEnd, tDate, tTime));

                                log.addLog(new Logs("Place Hold", user, dateStart, timeStart, dateEnd, timeEnd, title, confirmNum, fee, tDate, tTime));
                                Intent main = new Intent(PlaceHold2.this, MainActivity.class);
                                startActivity(main);
                                break;

                            }
                        }

                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void invalid(EditText format) {
        format.setError("Invalid");
    }
}
