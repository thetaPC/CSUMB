package io.github.thetapc.otterlibrarysystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Maria on 12/6/2016.
 */

public class LibraryBookDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LibraryBookDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_BOOKS = "books";
    private static final String KEY_ID = "id";
    private static final String KEY_TITLE = "title";
    private static final String KEY_AUTHOR = "author";
    private static final String KEY_ISBN = "isbn";
    private static final String KEY_FEEHR = "fee";
    private static final String KEY_AVAIL = "available";
    private static final String[] COLUMNS = {KEY_ID, KEY_TITLE, KEY_AUTHOR, KEY_ISBN, KEY_FEEHR, KEY_AVAIL};

    public LibraryBookDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_BOOK_TABLE = "CREATE TABLE books ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "title TEXT, " + "author TEXT, " + "isbn TEXT, " + "fee REAL, " + "available TEXT)";

        db.execSQL(CREATE_BOOK_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS books");
        this.onCreate(db);

    }

    public void deleteTable() {
        SQLiteDatabase db =  this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS books");
        this.onCreate(db);
    }

    public void addBook(Book book) {
        Log.d("addBook", book.toString());
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TITLE, book.getTitle());
        values.put(KEY_AUTHOR, book.getAuthor());
        values.put(KEY_ISBN, book.getISBN());
        values.put(KEY_FEEHR, book.getFee());
        values.put(KEY_AVAIL, book.getAvailability());

        db.insert(TABLE_BOOKS, null, values);
        db.close();
    }

    public Book getBook(String avail) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_BOOKS, COLUMNS, " available = ?", new String[] { String.valueOf(avail) }, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Book book = new Book();
        book.setId(Integer.parseInt(cursor.getString(0)));

        book.setTitle(cursor.getString(1));
        book.setAuthor(cursor.getString(2));
        book.setISBN(cursor.getString(3));
        book.setFee(cursor.getDouble(4));
        book.setAvailablility(cursor.getString(5));

        Log.d("getBook("+avail+")", book.toString());
        return book;

    }

    public ArrayList<Book> getAllBooks() {
        ArrayList<Book> books = new ArrayList<Book>();
        String query = "SELECT * FROM " + TABLE_BOOKS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Book book = null;
        if (cursor.moveToFirst()) {
            do {
                book = new Book();
                book.setId(Integer.parseInt(cursor.getString(0)));
                book.setTitle(cursor.getString(1));
                book.setAuthor(cursor.getString(2));
                book.setISBN(cursor.getString(3));
                book.setFee(cursor.getDouble(4));
                book.setAvailablility(cursor.getString(5));
                books.add(book);
            } while (cursor.moveToNext());
        }

        Log.d("getAllBooks()", books.toString());

        return books;
    }

    public ArrayList<Book> getAvailBooks() {
        ArrayList<Book> books = new ArrayList<Book>();
        String query = "SELECT * FROM " + TABLE_BOOKS + " WHERE " + KEY_AVAIL + " = 'yes'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Book book = null;
        if (cursor.moveToFirst()) {
            do {
                book = new Book();
                book.setId(Integer.parseInt(cursor.getString(0)));
                book.setTitle(cursor.getString(1));
                book.setAuthor(cursor.getString(2));
                book.setISBN(cursor.getString(3));
                book.setFee(cursor.getDouble(4));
                book.setAvailablility(cursor.getString(5));
                books.add(book);
            } while (cursor.moveToNext());
        }

        Log.d("getAvailBooks()", books.toString());

        return books;
    }

    public int updateBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", book.getTitle());
        values.put("author", book.getAuthor());
        values.put("isbn", book.getISBN());
        values.put("fee", book.getFee());
        values.put("available", book.getAvailability());


        int i = db.update(TABLE_BOOKS, values, KEY_ID+" = ?", new String[] { String.valueOf(book.getId()) });

        db.close();
        return i;
    }

    public void deleteBook(Book book) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_BOOKS, KEY_ID+" = ?", new String[] { String.valueOf(book.getId()) });
        db.close();

        Log.d("deleteBook", book.toString());
    }


}

