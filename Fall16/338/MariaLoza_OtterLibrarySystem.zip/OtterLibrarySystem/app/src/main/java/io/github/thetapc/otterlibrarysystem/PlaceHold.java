package io.github.thetapc.otterlibrarysystem;

import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.IntegerRes;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.concurrent.ThreadLocalRandom;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedMap;

public class PlaceHold extends AppCompatActivity implements OnClickListener {

    private ArrayList<Book> allBooks = new ArrayList<Book>();
    private ArrayList<Acct> allAccts = new ArrayList<Acct>();
    private LibraryAccountDB acct;
    private LibraryBookDB db;
    private LibraryHoldDB holdBook;
    private LibraryLogDB log = new LibraryLogDB(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_hold);

        holdBook = new LibraryHoldDB(this);

        ///////////////////////////////////////
      //  holdBook.deleteTable();
        //////////////////////////////////////

        acct = new LibraryAccountDB(this);
        allAccts = acct.getAllAccts();

        db = new LibraryBookDB(this);

        /////////////////////////////////////
      //  db.deleteTable();
        ////////////////////////////////////

    //    db.addBook(new Book("Hot Java", "S. Narayanan", "123-ABC-101", 0.05, "yes"));
    //   db.addBook(new Book("Fun Java", "Y. Byun", "ABCDEF-09", 1.00, "yes"));
     //  db.addBook(new Book("Algorithm for Java", "K. Alice", "CDE-777-123 ", 0.25, "yes"));

        allBooks = db.getAvailBooks();

        View newHold = findViewById(R.id.plcHold);
        newHold.setOnClickListener(this);

        /*
        final EditText month = (EditText)findViewById(R.id.month);
        month.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
                String mName = month.getText().toString();
                Log.d("test ", mName);
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText day = (EditText)findViewById(R.id.day);
        day.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText yr = (EditText)findViewById(R.id.year);
        yr.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText hr = (EditText)findViewById(R.id.hour);
        hr.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText min = (EditText)findViewById(R.id.min );
        min.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });

        EditText rMonth = (EditText)findViewById(R.id.rMonth);
        rMonth.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText rDay = (EditText)findViewById(R.id.rDay);
        rDay.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText rYr = (EditText)findViewById(R.id.rYear);
        rYr.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText rHr = (EditText)findViewById(R.id.rHour);
        rHr.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });
        EditText rMin = (EditText)findViewById(R.id.rMin );
        rMin.addTextChangedListener(new TextWatcher() {

            public void afterTextChanged(Editable s) {
            }

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {

            }
        });

         */





    }



    public void onClick(View view) {

        try {

        boolean correct = true;
        int timeOfDay;
        int rTimeOfDay;
            int monthNum = 0;
            int dayNum = 0;
            int yrNum = 0;
            int hrNum = 0;
            int minNum = 0;
            int rMonthNum = 0;
            int rDayNum = 0;
            int rYrNum = 0;
            int rHrNum = 0;
            int rMinNum = 0;

            Button hold = (Button)findViewById(R.id.plcHold);

        EditText month = (EditText)findViewById(R.id.month);
       // String mnt = month.getText().toString();
            if (month.getText().toString().equals("")) {
                correct = false;
            } else {
                monthNum = Integer.parseInt(month.getText().toString());
            }

        EditText day = (EditText)findViewById(R.id.day);
            if (day.getText().toString().equals("")) {
                correct = false;
            } else {
                dayNum = Integer.parseInt(day.getText().toString());
            }

        EditText yr = (EditText)findViewById(R.id.year);
            if (yr.getText().toString().equals("")) {
                correct = false;
            } else {
                yrNum = Integer.parseInt(yr.getText().toString());
            }


        EditText hr = (EditText)findViewById(R.id.hour);
            if (hr.getText().toString().equals("")) {
                correct = false;
            } else {
                 hrNum = Integer.parseInt(hr.getText().toString());
            }

        EditText min = (EditText)findViewById(R.id.min );
            if (min.getText().toString().equals("")) {
                correct = false;
            } else {
                 minNum = Integer.parseInt(min.getText().toString());
            }

        RadioButton am = (RadioButton)findViewById(R.id.AM);
        RadioButton pm = (RadioButton)findViewById(R.id.PM);

        EditText rMonth = (EditText)findViewById(R.id.rMonth);
            if (rMonth.getText().toString().equals("")) {
                correct = false;
            } else {
                 rMonthNum = Integer.parseInt(rMonth.getText().toString());
            }

        EditText rDay = (EditText)findViewById(R.id.rDay);
            if (rMonth.getText().toString().equals("")) {
                correct = false;
            } else {
                 rDayNum = Integer.parseInt(rDay.getText().toString());
            }

        EditText rYr = (EditText)findViewById(R.id.rYear);
            if (rYr.getText().toString().equals("")) {
                correct = false;
            } else {
                 rYrNum = Integer.parseInt(rYr.getText().toString());
            }


        EditText rHr = (EditText)findViewById(R.id.rHour);
        if (rHr.getText().toString().equals("")) {
            correct = false;
        } else {
             rHrNum = Integer.parseInt(rHr.getText().toString());
        }
        EditText rMin = (EditText)findViewById(R.id.rMin );
            if (rMin.getText().toString().equals("")) {
                correct = false;
            } else {
                 rMinNum = Integer.parseInt(rMin.getText().toString());
            }

        RadioButton rAM = (RadioButton)findViewById(R.id.rAM);
        RadioButton rPM = (RadioButton)findViewById(R.id.rPM);

        long diffDays = 0;
        long totalHours = 0;

        if (view.getId() == R.id.plcHold) {
            if(month.getText().toString().equals("") || monthNum <= 0 || monthNum > 12) {
                showError(month);
                correct = false;
            }

            if (day.getText().toString().equals("") || dayNum <= 0 || dayNum > 31) {
                showError(day);
                correct = false;
            }

            if (yr.getText().toString().equals("") || yrNum <= 2015) {
                showYrError(yr);
                correct = false;
            }

            if (hr.getText().toString().equals("") || hrNum <= 0 || hrNum > 12) {
                showError(hr);
                correct = false;
            }

            if (min.getText().toString().equals("") || minNum < 0 || minNum > 59) {
                showError(min);
                correct = false;
            }



            if(rMonth.getText().toString().equals("") || rMonthNum <= 0 || rMonthNum > 12) {
                showError(rMonth);
                correct = false;
            }

            if (rDay.getText().toString().equals("") || rDayNum <= 0 || rDayNum > 31) {
                showError(rDay);
                correct = false;
            }

            if (rYr.getText().toString().equals("") || rYrNum <= 2015) {
                showYrError(rYr);
                correct = false;
            }

            if (rHr.getText().toString().equals("") || rHrNum <= 0 || rHrNum > 12) {
                showError(rHr);
                correct = false;
            }

            if (rMin.getText().toString().equals("") || rMinNum < 0 || rMinNum > 59) {
                showError(rMin);
                correct = false;
            }



            Log.d("correct 0: ", String.valueOf(correct));

            if (correct) {
                String date = month.getText().toString() + "/" + day.getText().toString() + "/" + yr.getText().toString();
                String time = hr.getText().toString() + ":" + min.getText().toString();
                String pDT = date + " " + time;
                String dateStart = date;
                String timeStart = time;
                if (am.isChecked()) {
                    timeOfDay = 1;
                    timeStart += " AM";
                } else if (pm.isChecked()) {
                    timeOfDay = 2;
                    timeStart += " PM";
                }

                String date2 = rMonth.getText().toString() + "/" + rDay.getText().toString() + "/" + rYr.getText().toString();
                String time2 = rHr.getText().toString() + ":" + rMin.getText().toString();
                String rDT = date2 + " " + time2;
                String dateEnd = date2;
                String timeEnd = time2;
                if (rAM.isChecked()) {
                    rTimeOfDay = 1;
                    timeEnd += " AM";
                } else if (rPM.isChecked()) {
                    rTimeOfDay = 2;
                    timeEnd += " PM";
                }


                DateFormat readFormat = new SimpleDateFormat( "MM/dd/yyyy hh:mm aa");
                DateFormat writeFormat = new SimpleDateFormat( "MM/dd/yyyy HH:mm");

                Log.d("correct 3: ", String.valueOf(correct));
                //SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy HH:mm");

                SimpleDateFormat parseTime = new SimpleDateFormat("hh:mm a");
                SimpleDateFormat parseDate = new SimpleDateFormat("MM/dd/yyyy");

                Date d1 = readFormat.parse(dateStart + " " + timeStart);
                Date d2 = readFormat.parse(dateEnd + " " + timeEnd);






               // Log.d("before: ", parseFormat.format(date3));
                Log.d("after start: ", readFormat.format(d1));
                Log.d("after end: ", readFormat.format(d2));

                   // Date d1 = format.parse(pDT);
                  //  Date d2 = format.parse(rDT);

                    long diff = d2.getTime() - d1.getTime();
                    diffDays = diff / (24 * 60 * 60 * 1000);
                Log.d("Days: ", Long.toString(diffDays));
                    totalHours = (diff / (60 * 60 * 1000) % 24) + (diffDays * 24);
                Log.d("totalHours: ", Long.toString(totalHours));
                    long diffHours = (diff / (60 * 60 * 1000) % 24);
                Log.d("diff hours: ", Long.toString(diffHours));
                    diffDays = diffDays + (diffHours * (long)0.0416667);

                Log.d("DaysAfter: ", Long.toString(diffDays));
                    //show(user, Long.toString(diffHours));

                Log.d("correct 6: ", Long.toString(diffDays));

                if (diffDays <= 7) {

                    if (allBooks.isEmpty()) {
                        noBooks();
                    } else {
                        Intent myIntent = new Intent(PlaceHold.this, PlaceHold2.class);
                        myIntent.putExtra("totalHours", totalHours);
                        myIntent.putExtra("dateStart", dateStart);
                        myIntent.putExtra("dateEnd", dateEnd);
                        myIntent.putExtra("timeStart", timeStart);
                        myIntent.putExtra("timeEnd", timeEnd);
                        startActivity(myIntent);
                    }



                } else {
                    passedSeven();
                }

            }
        }

        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    private void confirmDialog(final String user, final String dateStart, final String dateEnd, final String title,
                               final int confirmNum, final double fee, final LibraryBookDB db,
                               final LibraryHoldDB hold, final LibraryLogDB log, final String author, final String isbn,
                               final String timeStart, final String timeEnd) {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(PlaceHold.this).create();
        alertDialog.setTitle("Place Hold");
        NumberFormat format = NumberFormat.getCurrencyInstance();
        alertDialog.setMessage(user + " " + dateStart + " " + timeStart + " " + dateEnd + " " + timeEnd + " "
                + title + " " + confirmNum + " " + format.format(fee));
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code
                        for (Book book: allBooks) {
                            if (title.equals(book.getTitle())) {
                                book.setAvailablility("no");
                                db.updateBook(book);
                                DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                                Date currDate;
                                currDate = new Date();
                                String tDate = dateFormat.format(currDate); //11/16/2016
                                DateFormat dateFormat2 = new SimpleDateFormat("HH:mm:ss");
                                Date currTime;
                                currTime = new Date();
                                String tTime = dateFormat2.format(currTime); // 12:08:43
                                hold.addBookToAcct(new Hold(user, title, author, isbn, fee, confirmNum, dateStart, timeStart,
                                        dateEnd, timeEnd, tDate, tTime));

                                log.addLog(new Logs("place hold", user, dateStart, timeStart, dateEnd, timeEnd, title, confirmNum, fee, tDate, tTime));
                                Intent main = new Intent(PlaceHold.this, MainActivity.class);
                                startActivity(main);
                                break;

                            }
                        }

                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void passedSeven() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(PlaceHold.this).create();
        alertDialog.setTitle("Place Hold");
        NumberFormat format = NumberFormat.getCurrencyInstance();
        alertDialog.setMessage("Must return book within 7 days.");
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code


                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void noBooks() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(PlaceHold.this).create();
        alertDialog.setTitle("Place Hold");
        NumberFormat format = NumberFormat.getCurrencyInstance();
        alertDialog.setMessage("No books at the moment.");
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Exit",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code
                        Intent main = new Intent(PlaceHold.this, MainActivity.class);
                        startActivity(main);

                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void showError(EditText format) {
        format.setError(" Wrong format ");
    }
    private void showYrError(EditText format) {
        format.setError(" Pick a year after 2015 ");
    }
    private void invalid(EditText format) {
        format.setError("Invalid");
    }
}


