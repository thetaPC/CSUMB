package io.github.thetapc.otterlibrarysystem;

/**
 * Created by Maria on 12/6/2016.
 */

public class Book {

    private int mID;
    private String mTitle;
    private String mAuthor;
    private String mISBN;
    private double mFee;
    private String mAvailable;

    public Book() {
        mTitle = "";
        mAuthor = "";
        mISBN = "";
        mFee = 0;
        mAvailable = "";
    }

    public Book(String title, String author, String isbn, double fee, String avail) {
        mTitle = title;
        mAuthor = author;
        mISBN = isbn;
        mFee = fee;
        mAvailable = avail;
    }

    public String toString() {
        return "Book [id=" + mID + ", title=" + mTitle + ", author=" + mAuthor + ", isbn=" + mISBN + ", fee=" + mFee + ", available= " + mAvailable+" ]";
    }

    public String getTitle() {
        return mTitle;
    }

    public String getAuthor() {
        return mAuthor;
    }

    public String getISBN() {
        return mISBN;
    }

    public double getFee() {
        return mFee;
    }

    public int getId() { return mID; }

    public String getAvailability() { return mAvailable; }

    public void setId(int ID) {
        mID = ID;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public void setAuthor(String author) {
        mAuthor = author;
    }

    public void setISBN(String isbn) {
        mISBN = isbn;
    }

    public void setFee(double fee) {
        mFee = fee;
    }

    public void setAvailablility(String avail) { mAvailable = avail; }



}
