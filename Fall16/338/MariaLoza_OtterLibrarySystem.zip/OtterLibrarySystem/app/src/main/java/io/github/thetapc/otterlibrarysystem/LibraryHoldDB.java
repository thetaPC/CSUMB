package io.github.thetapc.otterlibrarysystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Maria on 12/8/2016.
 */

public class LibraryHoldDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LibraryHoldDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_BOOKS_HELD = "hold";
    private static final String KEY_ID = "id";
    private static final String KEY_USER = "username";
    private static final String KEY_TITLE = "title";
    private static final String KEY_AUTHOR = "author";
    private static final String KEY_ISBN = "isbn";
    private static final String KEY_FEEHR = "fee";
    private static final String KEY_RNUM = "reservationNum";
    private static final String KEY_PDATE = "pDate";
    private static final String KEY_PTIME = "pTime";
    private static final String KEY_RDATE = "rDate";
    private static final String KEY_RTIME = "rTime";
    private static final String KEY_TDATE = "tDate";
    private static final String KEY_TTIME = "tTime";
    private static final String[] COLUMNS = {KEY_ID, KEY_TITLE, KEY_AUTHOR, KEY_ISBN, KEY_FEEHR, KEY_RNUM, KEY_PDATE, KEY_PTIME, KEY_RDATE, KEY_RTIME, KEY_TDATE, KEY_TTIME};

    public LibraryHoldDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String TABLE_BOOKS_HELD = "CREATE TABLE hold ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "username TEXT, " + "title TEXT, " + "author TEXT, " + "isbn TEXT, " + "fee REAL, " +
                "reservationNum INTEGER, " + "pDate TEXT, " + "pTime TEXT, " + "rDate TEXT, " + "rTime TEXT, " + "tDate TEXT, " + "tTime TEXT)";

        db.execSQL(TABLE_BOOKS_HELD);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS hold");
        this.onCreate(db);

    }

    public void deleteTable() {
        SQLiteDatabase db =  this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS hold");
        this.onCreate(db);
    }

    public void addBookToAcct(Hold hold) {
        Log.d("addBookToAcct", hold.toString());
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USER, hold.getUsername());
        values.put(KEY_TITLE, hold.getTitle());
        values.put(KEY_AUTHOR, hold.getAuthor());
        values.put(KEY_ISBN, hold.getISBN());
        values.put(KEY_FEEHR, hold.getFee());
        values.put(KEY_RNUM, hold.getReserveNum());
        values.put(KEY_PDATE, hold.getPDate());
        values.put(KEY_PTIME, hold.getPTime());
        values.put(KEY_RDATE, hold.getRDate());
        values.put(KEY_RTIME, hold.getRTime());
        values.put(KEY_TDATE, hold.getTDate());
        values.put(KEY_TTIME, hold.getTTime());

        db.insert(TABLE_BOOKS_HELD, null, values);
        db.close();
    }

    public Hold getBookOnHold(String user) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_BOOKS_HELD, COLUMNS, " username = ?", new String[] { String.valueOf(user) }, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Hold hold = new Hold();
        hold.setId(Integer.parseInt(cursor.getString(0)));

        hold.setUsername(cursor.getString(1));
        hold.setTitle(cursor.getString(2));
        hold.setAuthor(cursor.getString(3));
        hold.setISBN(cursor.getString(4));
        hold.setFee(cursor.getDouble(5));
        hold.setReserveNum(cursor.getInt(6));
        hold.setPDate(cursor.getString(7));
        hold.setPTime(cursor.getString(8));
        hold.setRDate(cursor.getString(9));
        hold.setRTime(cursor.getString(10));
        hold.setTDate(cursor.getString(11));
        hold.setTTime(cursor.getString(12));


        Log.d("getBookOnHold("+user+")", hold.toString());
        return hold;

    }

    public ArrayList<Hold> getAllBooksOnHold(String user) {
        ArrayList<Hold> holds = new ArrayList<Hold>();
        String query = "SELECT * FROM " + TABLE_BOOKS_HELD + " WHERE " + KEY_USER + " = '" + user + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Hold hold = null;
        if (cursor.moveToFirst()) {
            do {
                hold = new Hold();
                hold.setId(Integer.parseInt(cursor.getString(0)));
                hold.setUsername(cursor.getString(1));
                hold.setTitle(cursor.getString(2));
                hold.setAuthor(cursor.getString(3));
                hold.setISBN(cursor.getString(4));
                hold.setFee(cursor.getDouble(5));
                hold.setReserveNum(cursor.getInt(6));
                hold.setPDate(cursor.getString(7));
                hold.setPTime(cursor.getString(8));
                hold.setRDate(cursor.getString(9));
                hold.setRTime(cursor.getString(10));
                hold.setTDate(cursor.getString(11));
                hold.setTTime(cursor.getString(12));

                holds.add(hold);
            } while (cursor.moveToNext());
        }

        Log.d("getAllBooksOnHold(user)", holds.toString());

        return holds;
    }

    public ArrayList<Hold> getAllBooksOnHold() {
        ArrayList<Hold> holds = new ArrayList<Hold>();
        String query = "SELECT * FROM " + TABLE_BOOKS_HELD;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Hold hold = null;
        if (cursor.moveToFirst()) {
            do {
                hold = new Hold();
                hold.setId(Integer.parseInt(cursor.getString(0)));
                hold.setUsername(cursor.getString(1));
                hold.setTitle(cursor.getString(2));
                hold.setAuthor(cursor.getString(3));
                hold.setISBN(cursor.getString(4));
                hold.setFee(cursor.getDouble(5));
                hold.setReserveNum(cursor.getInt(6));
                hold.setPDate(cursor.getString(7));
                hold.setPTime(cursor.getString(8));
                hold.setRDate(cursor.getString(9));
                hold.setRTime(cursor.getString(10));
                hold.setTDate(cursor.getString(11));
                hold.setTTime(cursor.getString(12));

                holds.add(hold);
            } while (cursor.moveToNext());
        }

        Log.d("getAllBooksOnHold()", holds.toString());

        return holds;
    }

    public int updateBookOnHold(Hold hold) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", hold.getUsername());
        values.put("title", hold.getTitle());
        values.put("author", hold.getAuthor());
        values.put("isbn", hold.getISBN());
        values.put("fee", hold.getFee());
        values.put("reservationNum", hold.getReserveNum());
        values.put("pDate", hold.getPDate());
        values.put("pTime", hold.getPTime());
        values.put("rDate", hold.getRDate());
        values.put("rTime", hold.getRTime());
        values.put("tDate", hold.getTDate());
        values.put("tTime", hold.getTTime());



        int i = db.update(TABLE_BOOKS_HELD, values, KEY_ID+" = ?", new String[] { String.valueOf(hold.getId()) });

        db.close();
        return i;
    }

    public void deleteBookOnHold(Hold hold) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_BOOKS_HELD, KEY_ID+" = ?", new String[] { String.valueOf(hold.getId()) });
        db.close();

        Log.d("deleteBookOnHold", hold.toString());
    }


}


