package io.github.thetapc.otterlibrarysystem;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.view.View.OnClickListener;
import android.widget.TextView;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CancelHold extends AppCompatActivity implements OnClickListener {

    private String user;
    private ArrayList<Hold> allBooksOnHold = new ArrayList<Hold>();
    private ArrayList<Book> allBooks = new ArrayList<Book>();
    private LibraryBookDB dbook;
    private LibraryHoldDB db;
    private Spinner currBook;
    private LibraryLogDB log = new LibraryLogDB(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_hold);

        Intent intent = getIntent();
        user = intent.getStringExtra("username");

        dbook = new LibraryBookDB(this);
        allBooks = dbook.getAllBooks();

        db = new LibraryHoldDB(this);
        allBooksOnHold = db.getAllBooksOnHold(user);

        if (allBooksOnHold.isEmpty()) {
            confirm();
        } else {
            LinearLayout ll = (LinearLayout) findViewById(R.id.activity_cancel_hold);
            TextView tv = new TextView(this);
            tv.setText(user);
            tv.setId(ll.getId());
            ll.addView(tv);

            final Spinner currBook = new Spinner(this);
            currBook.setId(ll.getId() + 5);
            ll.addView(currBook);

            //currBook = (Spinner)findViewById(R.id.spinnerBk);
            List<String> list = new ArrayList<String>();
            //list.add("");
            for (Hold hold: allBooksOnHold) {
                list.add(hold.getTitle());
            }
            ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            currBook.setAdapter(dataAdapter);


//        currBook.setOnClickListener(this);
            currBook.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parentView, View selectedItemView,int position, long id)
                {
                    String bookTitle = currBook.getSelectedItem().toString();
                    confirmDialog(bookTitle, log);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }


    }



    public void onClick(View view) {

    }

    private void confirmDialog(final String title, final LibraryLogDB log) {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(CancelHold.this).create();
        alertDialog.setTitle("Cancel Hold");
        alertDialog.setMessage("Are you sure you want to cancel the hold for " + title + "?");
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "YES",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code
                        Log.d("yes ", title);

                        for (Book book: allBooks) {

                            if (title.equals(book.getTitle())) {

                                book.setAvailablility("yes");
                                Log.d("yes 2", title);
                                dbook.updateBook(book);
                                Log.d("yes update", title);
                                for (Hold hold: allBooksOnHold) {
                                    if (title.equals(hold.getTitle())) {

                                        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
                                        Date currDate;
                                        currDate = new Date();
                                        String tDate = dateFormat.format(currDate); //11/16/2016
                                        DateFormat dateFormat2 = new SimpleDateFormat("HH:mm");
                                        Date currTime;
                                        currTime = new Date();
                                        String tTime = dateFormat2.format(currTime); // 12:08
                                        Log.d("yes1 ", tDate + " " + tTime);

                                        Log.d("cancel ", title);
                                        db.deleteBookOnHold(hold);
                                        log.addLog(new Logs("Cancel hold", user, hold.getPDate(), hold.getPTime(), hold.getRDate(), hold.getRTime(), title, tDate, tTime));

                                        Intent main = new Intent(CancelHold.this, MainActivity.class);
                                        startActivity(main);
                                    }
                                }


                                break;
                            }
                        }

                        dialog.dismiss();
                    }
                });
        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "CANCEL",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

    private void confirm() {
        AlertDialog builder = new AlertDialog.Builder(getApplicationContext()).create();

        //alertDialog
        ////////////////////////////////////////////////////////////
        AlertDialog alertDialog = new AlertDialog.Builder(CancelHold.this).create();
        alertDialog.setTitle("No Holds");
        alertDialog.setMessage("No holds on account");
        //minutes do not show 05 but 5
        //ex: 10:5:00
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        //do code
                       // Log.d("yes ", title);

                        Intent main = new Intent(CancelHold.this, MainActivity.class);
                        startActivity(main);

                        dialog.dismiss();
                    }
                });
        alertDialog.show();
        ////////////////////////////////////////////////////////////
    }

}
