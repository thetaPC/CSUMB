package io.github.thetapc.otterlibrarysystem;

/**
 * Created by Maria on 12/9/2016.
 */

public class Logs {

    private int mID;
    private String mUsername;
    private String mType;
    private String mCDate;
    private String mCTime;
    private String mSDate;
    private String mSTime;
    private String mEDate;
    private String mETime;
    private String mTitle;
    private Double mFee;
    private int mRNum;


    public Logs() {
        mUsername = "";
        mType = "";
        mCDate = "";
        mCTime = "";
        mSDate = "";
        mSTime = "";
        mETime = "";
        mEDate = "";
        mTitle = "";
        mFee = 0.0;
        mRNum = 0;
    }

    public Logs(String type, String user, String cDate, String cTime) {
        mType = type;
        mUsername = user;
        mCDate = cDate;
        mCTime = cTime;
        mFee = 0.0;
    }

    public Logs(String type, String user, String sDate, String sTime, String eDate, String eTime,
                String title, int rNum, double fee, String cDate, String cTime) {
        mType = type;
        mUsername = user;
        mSDate = sDate;
        mSTime = sTime;
        mEDate = eDate;
        mETime = eTime;
        mTitle = title;
        mRNum = rNum;
        mFee = fee;
        mCDate = cDate;
        mCTime = cTime;
    }

    public Logs(String type, String user, String sDate, String sTime, String eDate, String eTime,
                String title, String cDate, String cTime) {
        mType = type;
        mUsername = user;
        mSDate = sDate;
        mSTime = sTime;
        mEDate = eDate;
        mETime = eTime;
        mTitle = title;
        mCDate = cDate;
        mCTime = cTime;
        mFee = 0.0;
    }

    public String toString() {
        return "Logs [id=" + mID + ", type=" + mType + ", username=" + mUsername +
                ", current date=" + mCDate + ", current time=" + mCTime + ", pickup date=" + mSDate +
                ", pickup time= " + mSTime + ", return date=" + mEDate + ", return time=" +
                mETime + ", book title=" + mTitle + ", total fee=" + mFee + ", reservation number=" + mRNum + "]";
    }

    public  int getId() { return mID; }

    public  String getUsername() { return  mUsername; }

    public String getType() {
        return mType;
    }

    public String getCDate() { return mCDate; }

    public String getCTime() { return mCTime; }

    public String getSDate() { return mSDate; }

    public String getSTime() { return mSTime; }

    public String getEDate() { return mEDate; }

    public String getETime() { return mETime; }

    public String getTitle() { return mTitle; }

    public double getFee() {
        return mFee;
    }

    public int getRNum() { return mRNum; }

    public void setId(int ID) {
        mID = ID;
    }

    public void setUsername(String user) {mUsername = user; }

    public void setType(String type) {
        mType = type;
    }

    public void setCDate(String date) { mCDate = date; }

    public void setCTime(String time) { mCTime = time; }

    public void setSDate(String date) { mSDate = date; }

    public void setSTime(String time) { mSTime = time; }

    public void setEDate(String date) { mEDate = date; }

    public void setETime(String time) { mETime = time; }

    public void setTitle(String title) { mTitle = title; }

    public void setFee(double fee) { mFee = fee; }

    public void setRNum(int num) { mRNum = num; }


}

