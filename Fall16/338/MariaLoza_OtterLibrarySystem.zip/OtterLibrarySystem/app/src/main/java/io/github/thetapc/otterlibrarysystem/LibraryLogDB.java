package io.github.thetapc.otterlibrarysystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Maria on 12/9/2016.
 */

public class LibraryLogDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LibraryLogsDB";
    private static final int DATABASE_VERSION = 2;

    private static final String TABLE_LOGS_HELD = "libLogs";
    private static final String KEY_ID = "id";
    private static final String KEY_TYPE = "type";
    private static final String KEY_USER = "username";
    private static final String KEY_CDATE = "cDate";
    private static final String KEY_CTIME = "cTime";
    private static final String KEY_SDATE = "sDate";
    private static final String KEY_STIME = "sTime";
    private static final String KEY_EDATE = "eDate";
    private static final String KEY_ETIME = "eTime";
    private static final String KEY_TITLE = "title";
    private static final String KEY_FEEHR = "fee";
    private static final String KEY_RNUM = "reservationNum";
    private static final String[] COLUMNS = {KEY_ID, KEY_TYPE, KEY_USER, KEY_CDATE, KEY_CTIME, KEY_SDATE, KEY_STIME, KEY_EDATE, KEY_ETIME, KEY_TITLE, KEY_FEEHR, KEY_RNUM};

    public LibraryLogDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String TABLE_LOGS_HELD = "CREATE TABLE libLogs ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "type TEXT, " + "username TEXT, " +
                "cDate TEXT, " + "cTime TEXT, " + "sDate TEXT, " + "sTime TEXT, " + "eDate TEXT, " +
                "eTime TEXT, " + "title TEXT, " + "fee REAL, " + "reservationNum INTEGER)";


        db.execSQL(TABLE_LOGS_HELD);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS libLogs");
        this.onCreate(db);

    }

    public void deleteTable() {
        SQLiteDatabase db =  this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS libLogs");
        this.onCreate(db);
        String test = "deleted libLogs";
        Log.d("deleteTable", test);
    }

    public void addLog(Logs lLogs) {
        Log.d("addLog", lLogs.toString());
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_TYPE, lLogs.getType());
        values.put(KEY_USER, lLogs.getUsername());
        values.put(KEY_CDATE, lLogs.getCDate());
        values.put(KEY_CTIME, lLogs.getCTime());
        values.put(KEY_SDATE, lLogs.getSDate());
        values.put(KEY_STIME, lLogs.getSTime());
        values.put(KEY_EDATE, lLogs.getEDate());
        values.put(KEY_ETIME, lLogs.getETime());
        values.put(KEY_TITLE, lLogs.getTitle());
        values.put(KEY_FEEHR, lLogs.getFee());
        values.put(KEY_RNUM, lLogs.getRNum());

        db.insert(TABLE_LOGS_HELD, null, values);
        db.close();
    }

    public Logs getLog(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_LOGS_HELD, COLUMNS, " id = ?", new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Logs lLogs = new Logs();
        lLogs.setId(Integer.parseInt(cursor.getString(0)));
        lLogs.setType(cursor.getString(1));
        lLogs.setUsername(cursor.getString(2));
        lLogs.setCDate(cursor.getString(3));
        lLogs.setCTime(cursor.getString(4));
        lLogs.setSDate(cursor.getString(5));
        lLogs.setSTime(cursor.getString(6));
        lLogs.setEDate(cursor.getString(7));
        lLogs.setETime(cursor.getString(8));
        lLogs.setTitle(cursor.getString(9));
        lLogs.setFee(cursor.getDouble(10));
        lLogs.setRNum(cursor.getInt(11));


        Log.d("getLog("+id+")", lLogs.toString());
        return lLogs;

    }

    public ArrayList<Logs> getAllLogs() {
        ArrayList<Logs> lLogs = new ArrayList<Logs>();
        String query = "SELECT * FROM " + TABLE_LOGS_HELD;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Logs lLog = null;
        if (cursor.moveToFirst()) {
            do {
                lLog = new Logs();
                lLog.setId(Integer.parseInt(cursor.getString(0)));
                lLog.setType(cursor.getString(1));
                lLog.setUsername(cursor.getString(2));
                lLog.setCDate(cursor.getString(3));
                lLog.setCTime(cursor.getString(4));
                lLog.setSDate(cursor.getString(5));
                lLog.setSTime(cursor.getString(6));
                lLog.setEDate(cursor.getString(7));
                lLog.setETime(cursor.getString(8));
                lLog.setTitle(cursor.getString(9));
                lLog.setFee(cursor.getDouble(10));
                lLog.setRNum(cursor.getInt(11));

                lLogs.add(lLog);
            } while (cursor.moveToNext());
        }

        Log.d("getAllLogs()", lLogs.toString());

        return lLogs;
    }


    public void deleteLogs(Logs lLog) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_LOGS_HELD, KEY_ID+" = ?", new String[] { String.valueOf(lLog.getId()) });
        db.close();

        Log.d("deleteLogs", lLog.toString());
    }


}