package io.github.thetapc.otterlibrarysystem;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by Maria on 12/1/2016.
 */

public class LibraryAccountDB extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "LibraryAccountDB";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_ACCTS = "accts";
    private static final String KEY_ID = "id";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";
    private static final String[] COLUMNS = {KEY_ID, KEY_USERNAME, KEY_PASSWORD};

    public LibraryAccountDB(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_ACCT_TABLE = "CREATE TABLE accts ( " + "id INTEGER PRIMARY KEY AUTOINCREMENT, " + "username TEXT, " + "password TEXT )";

        db.execSQL(CREATE_ACCT_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS accts");
        this.onCreate(db);

    }

    public void deleteTable() {
        SQLiteDatabase db =  this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS accts");
        this.onCreate(db);
    }

    public void addAcct(Acct acct) {
        Log.d("addAcct", acct.toString());
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, acct.getUsername());
        values.put(KEY_PASSWORD, acct.getPassword());

        //db.insert(TABLE_ACCTS, null, values);
        db.insertWithOnConflict(TABLE_ACCTS, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public Acct getAcct(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_ACCTS, COLUMNS, " id = ?", new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null) {
            cursor.moveToFirst();
        }

        Acct account = new Acct();
        account.setId(Integer.parseInt(cursor.getString(0)));

        account.setUser(cursor.getString(1));
        account.setPass(cursor.getString(2));

        Log.d("getAcct("+id+")", account.toString());
        return account;

    }

    public ArrayList<Acct> getAllAccts() {
        ArrayList<Acct> accts = new ArrayList<Acct>();
        String query = "SELECT * FROM " + TABLE_ACCTS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Acct account = null;
        if (cursor.moveToFirst()) {
            do {
                account = new Acct();
                account.setId(Integer.parseInt(cursor.getString(0)));
                account.setUser(cursor.getString(1));
                account.setPass(cursor.getString(2));
                accts.add(account);
            } while (cursor.moveToNext());
        }

        Log.d("getAllAccts()", accts.toString());

        return accts;
    }

    public int updateAcct(Acct acct) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user", acct.getUsername());
        values.put("pass", acct.getPassword());

        int i = db.update(TABLE_ACCTS, values, KEY_ID+" = ?", new String[] { String.valueOf(acct.getId()) });

        db.close();
        return i;
    }

    public void deleteAcct(Acct acct) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TABLE_ACCTS, KEY_ID+" = ?", new String[] { String.valueOf(acct.getId()) });
        db.close();

        Log.d("deleteAcct", acct.toString());
    }


}

