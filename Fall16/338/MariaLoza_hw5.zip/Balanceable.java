/*
	Balanceable.java
	
	Abstract: 
	Introduces the method getBalance but won't be created 'til Account.java b/c Balanceable is an interface
	
	Maria Loza
	
	19 October 2016

*/

public interface Balanceable {

	public double getBalance();
	
	public void setBalance(double amount);


}