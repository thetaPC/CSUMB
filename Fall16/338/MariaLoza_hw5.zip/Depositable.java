/*
	Depositable.java
	
	Abstract: 
	Introduces the method deposit but won't be created 'til Account.java b/c Depositable is an interface
	
	Maria Loza
	
	19 October 2016

*/

public interface Depositable {

	public void deposit(double amount);
	


}