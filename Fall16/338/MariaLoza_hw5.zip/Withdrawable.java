/*
	Withdrawable.java
	
	Abstract: 
	Introduces the method withdraw but won't be created 'til Account.java b/c Withdrawable is an interface
	
	Maria Loza
	
	19 October 2016

*/

public interface Withdrawable {

	public void withdraw(double amount);

}