/*
	SavingsAccount.java
	
	Abstract: 
	Adds onto Account. 
	calculates the payment after the month using the rate. The rate is also updated using the constructor. The balance is updated upon getting the payment.
	
	Maria Loza
	
	19 October 2016
	20 October 2016

*/

public class SavingsAccount extends Account {

	private double monthlyIntRate;
	private double monthlyIntPayment;

	public SavingsAccount() {
		monthlyIntRate = 0;
	}
	
	public SavingsAccount(double rate) {
		if (rate < 1 && rate > 0) {
			monthlyIntRate = rate;
		} else {
			System.out.println("\nInvalid rate, must be below 1 and positive. Interest rate will be 0.");
			monthlyIntRate = 0;
		}
		
	}
	
	public double getIntPayment() {
		monthlyIntPayment = super.getBalance() * monthlyIntRate;
		super.setBalance(super.getBalance() + monthlyIntPayment);
		return monthlyIntPayment;
	}
	
	public double getRate() {
		return monthlyIntRate;
	}
	


}