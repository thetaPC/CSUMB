/*
	CheckingAccount.java
	
	Abstract: 
	Adds onto Account.java 
	calculates the new balance after the fee is added. The fee is also updated using the constructor. Deposit and withdraw methods are overriden for this specific class. 
	
	Maria Loza
	
	19 October 2016
	20 October 2016

*/

public class CheckingAccount extends Account {
	
	private double monthlyFee;
	private static int checkUsage = 0;
	private boolean flag = true;
	
	public CheckingAccount() {
		monthlyFee = 0;
	}
	
	public CheckingAccount(double fee) {
		if (fee >= 0) {
			monthlyFee = fee;
		} else {
			System.out.println("\nInvalid fee, must be positive. Fee will be 0.");
			monthlyFee = 0;
		}
		
		//flag = true;
	}
	
	public void calcBal() {
		//System.out.println(super.getBalance());
		double bal = super.getBalance() - getFee();
		//System.out.println(getFee());
		super.setBalance(bal);
	}
	
	public double getInitialFee() {
		return monthlyFee;
	}
	
	public void calcFee() {
		if (checkUsage > 0) {
			monthlyFee *= checkUsage;
		}
		if (checkUsage == 0) {
			monthlyFee = 0;
		}
	}
	
	public double getFee() {
		if (flag) {
			calcFee();
		}
		flag = false;
		return monthlyFee;
	}
	
	public void deposit(double amount) {
		super.deposit(amount);
		checkUsage++;
		//flag = false;
		//System.out.println("test0");
	}
	
	public void withdraw(double amount) {
		super.withdraw(amount);
		checkUsage++;
		//flag = false;
		//System.out.println("test1");
	}


}