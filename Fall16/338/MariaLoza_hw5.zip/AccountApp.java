/*
	AccountApp.java
	
	Abstract: 
	
	Maria Loza
	
	19 October 2016

*/

import java.util.Scanner;


public class AccountApp {
	public static void main(String[] args) {
		
		Scanner keyboard = new Scanner(System.in);
		
		double checkAmt;
		double savingsAmt;
		double fee;
		double rate;
		char transOption, acctOption;
		double amt;
		char continueOption = 'y';
		
		
		System.out.println("Welcome to the Account application");
		
		System.out.println("");
		
		System.out.print("Enter initial Checking amount: ");
		checkAmt = keyboard.nextDouble();
		System.out.print("Enter initial Savings amount: ");
		savingsAmt = keyboard.nextDouble();
		System.out.print("Enter Checking fee: ");
		fee = keyboard.nextDouble();
		CheckingAccount checkAcct = new CheckingAccount(fee);
		System.out.print("Enter Savings interest rate: ");
		rate = keyboard.nextDouble();
		SavingsAccount savingsAcct = new SavingsAccount(rate);
		
		checkAcct.setBalance(checkAmt);
		savingsAcct.setBalance(savingsAmt);
		
		System.out.println("");
		
		System.out.println("Ok! This is your information");
		System.out.println("Checking Amount: " + checkAcct.formatMoney( checkAcct.getBalance() )  );
		System.out.println("Savings Amount: " + savingsAcct.formatMoney( savingsAcct.getBalance() ) );
		System.out.println("Checking Fee: " + checkAcct.formatMoney( checkAcct.getInitialFee() ) );
		System.out.println("Interest Rate: " + savingsAcct.formatPercent( savingsAcct.getRate() ) );
		
		System.out.println("");
		
		System.out.println("Enter the transactions for the month");

		while (continueOption == 'y') {
			
			System.out.print("Withdraw or deposit? (w/d): ");
			transOption = keyboard.next().charAt(0);
			//System.out.print("Checking or Savings? (c/s): ");
			//acctOption = keyboard.next().charAt(0);
			//System.out.print("Amount?: ");
			//amt = keyboard.nextDouble();
			if (transOption == 'w') {
				System.out.print("Checking or Savings? (c/s): ");
				acctOption = keyboard.next().charAt(0);
				if (acctOption == 'c') {
					System.out.print("Amount?: ");
					amt = keyboard.nextDouble();
					checkAcct.withdraw(amt);
				} else if (acctOption == 's') {
					System.out.print("Amount?: ");
					amt = keyboard.nextDouble();
					savingsAcct.withdraw(amt);
				} else {
					System.out.println("Invalid account selection. Try again later.");
				}
			} else if (transOption == 'd') {
				System.out.print("Checking or Savings? (c/s): ");
				acctOption = keyboard.next().charAt(0);
				if (acctOption == 'c') {
					System.out.print("Amount?: ");
					amt = keyboard.nextDouble();
					checkAcct.deposit(amt);
				} else if (acctOption == 's') {
					System.out.print("Amount?: ");
					amt = keyboard.nextDouble();
					savingsAcct.deposit(amt);
				} else {
					System.out.println("Invalid account selection. Try again later.");
				}
			} else {
				System.out.println("Invalid transaction. Try again later.");
			}
			
			System.out.println("");
			
			System.out.print("Continue? (y/n): ");
			continueOption = keyboard.next().charAt(0);
			while (continueOption != 'y' && continueOption != 'n') {
				System.out.println("Invalid input");
				System.out.print("Continue? (y/n): ");
				continueOption = keyboard.next().charAt(0);
			}

			System.out. println("");
			
		}
		
		System.out. println("");
		
		System.out. println("Monthly Payments and Fees");
		System.out. println("Checking fee:			" + checkAcct.formatMoney( checkAcct.getFee() ) );
		checkAcct.calcBal();
		System.out. println("Savings interest payment:	" +savingsAcct.formatMoney( savingsAcct.getIntPayment() ) );
		
		System.out. println("");
		
		System.out. println("Final Balances");
		System.out. println("Checking:	" + checkAcct.formatMoney( checkAcct.getBalance( ) ) );
		System.out. println("Savings:	" + savingsAcct.formatMoney( savingsAcct.getBalance() ) );
		
		System.out. println("");
		
		
	}
}