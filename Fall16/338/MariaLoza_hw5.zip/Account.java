/*
	Account.java
	
	Abstract: 
	Creates all the functions in Depositable, Withdrawable, and Balanceable.
	It also sets the balance for the accounts. Doubles are also formatted for money or percentages.
	
	Maria Loza
	
	19 October 2016
	20 October 2016

*/

public class Account implements Depositable, Withdrawable, Balanceable {
	
	private double balance;
	
	public Account() {
		
	}

	public void deposit(double amount) {
		if (amount > 0) {
			balance += amount;
		} else {
			System.out.println("Deposit amount is not valid.");
		}
	}
	
	public void withdraw(double amount) {
		if (amount > 0) {
			double possBal = balance - amount;
			//System.out.println(possBal);
			if (possBal >= 0) {
				balance -= amount;
			} else {
				System.out.println("Invalid. Balance cannot be negative.");
			}
		} else {
			System.out.println("Withdraw amount is not valid.");
		}
		
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double amount) {
		if (amount >= 0) {
			balance = amount;
		} else {
			System.out.println("\nInvalid amount. Balance will be 0.");
			balance = 0;
		}
		
	}
	
	public 	String formatMoney(double bal) {
		return String.format("$%2.2f", bal);
	}
	
	public 	String formatPercent(double perc) {
		perc *= 100;
		return String.format("%2.2f%s", perc, "%");
	}


}